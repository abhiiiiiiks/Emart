# E-Mart
Electronic Mart or simply E-Mart, is an e-commerce website where people can buy/sell electronic gadgets. It aims to provide the customers with best and high-quality products at nominal rates.

Steps to open Project
1. Download Repositry as Zip and then extract it.
2. Open index.html file which contains the home page of the website.

# HURRAY!! ALL SET TO EXPLORE WEBSITE

- Here are some of the screenshots of the project :
![image](https://user-images.githubusercontent.com/65806215/114375724-97e05200-9ba2-11eb-9a50-b0b3b4d3b2fd.png)
![image](https://user-images.githubusercontent.com/65806215/114375767-a464aa80-9ba2-11eb-9aa3-50ab2cdb94e2.png)
![image](https://user-images.githubusercontent.com/65806215/114374852-b5f98280-9ba1-11eb-97bd-9a174e9eb15d.png)
![image](https://user-images.githubusercontent.com/65806215/114375213-12f53880-9ba2-11eb-848f-23b112616e2a.png)
![image](https://user-images.githubusercontent.com/65806215/114375350-2e604380-9ba2-11eb-90f5-6e7894371640.png)
![image](https://user-images.githubusercontent.com/65806215/114375634-7da67400-9ba2-11eb-8660-10dfeb9fb01e.png)
![image](https://user-images.githubusercontent.com/65806215/114375867-bd6d5b80-9ba2-11eb-89d0-be4f3842cccc.png)

